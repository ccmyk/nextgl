"use client";
import Playground from "@/components/views/Playground";

export default function PlaygroundPage() {
  return (
    <main className="playground-page">
      <Playground />
    </main>
  );
}