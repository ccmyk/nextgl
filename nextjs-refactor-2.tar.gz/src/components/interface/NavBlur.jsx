"use client"

export default function NavBlur() {
  return (
    <div className="nav_blur">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  )
}
